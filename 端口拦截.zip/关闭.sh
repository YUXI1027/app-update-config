/system/bin/iptables -F
/system/bin/iptables -X 
/system/bin/iptables -Z
/system/bin/iptables -t nat -F